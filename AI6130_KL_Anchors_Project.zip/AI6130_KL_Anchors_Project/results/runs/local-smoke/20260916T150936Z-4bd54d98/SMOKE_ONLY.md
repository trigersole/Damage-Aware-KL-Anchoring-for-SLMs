# Synthetic local smoke test

These inputs and model are synthetic. The script substitutes a tiny PyTorch model for Qwen and does not exercise PEFT LoRA or a Hugging Face model. Its losses and selected anchors are not research results.
