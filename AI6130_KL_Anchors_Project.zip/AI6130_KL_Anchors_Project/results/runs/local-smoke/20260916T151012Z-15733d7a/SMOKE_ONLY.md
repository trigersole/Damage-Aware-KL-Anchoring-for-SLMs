# Synthetic local smoke test

These inputs and model are synthetic. The script substitutes a tiny PyTorch model for Qwen and does not exercise PEFT LoRA or a Hugging Face model. The saved adapter files are stubs, not reloadable model weights. Its losses and selected anchors are not research results.
